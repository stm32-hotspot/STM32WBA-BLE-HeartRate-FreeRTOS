**
  ***************************************************************************************************
  * @file    readme.txt 
  * @author  MCD Application Team
  * @brief   Description of  how to add STM32WBAxx devices support on MDK-ARM.
  ***************************************************************************************************
  * @attention
  *
  * Copyright (c) 2023 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  *************************************************************************************************
  
  Package general purpose:
  ===============================================================================================================================
	These packages contains the needed files to be installed in order to support STM32WBAxx devices by MDK-ARM v5.25 and laters.

	We inform you that this package is suitable for internal & external use.
  
  Running the "Keil.STM32WBAxx_DFP.1.4.0.pack" adds the following: 
  ================================================================================================================================ 
	1. Part numbers for  :
		- Product Number with 1MB Flash size: STM32WBA50xGxx/STM32WBA52xGxx/STM32WBA54xGxx/STM32WBA55xGxx/STM32WBA5MxGxx.  
		- Product Number with 512 kB Flash size: STM32WBA50xExx/STM32WBA52xExx/STM32WBA54xExx/STM32WBA55xExx
	
	- Automatic STM32WBAxx internal flash algorithm selection   
		
	2. The following SVD files will be added:
		- STM32WBA52 SVD files v1r2.
		- STM32WBA50 SVD files v0r3.
		- STM32WBA55 SVD files v0r3.
		- STM32WBA54 SVD files v0r3.


 How to use:
 =================================================================================================================================
	* Before installing the files mentioned above, you need to have MDK-ARM v5.25 
	  or later installed. 
	  You can download pack from keil web site @ www.keil.com
 
	* Double Clic on  "Keil.STM32WBAxx_DFP.1.4.0.pack" in order to install this pack in 
	  the Keil install directory.
	
	PS: Please make sure that you are using PackUnzip.exe to run this pack.
 
 
 SVD files ReleaseNotes:
 ==================================================================================================================================
    =======================================================
	STM32WBA55_v0r1: initial release
	=======================================================
	Doc ID:  RM0493 Rev 3 - October 2023
	Renamed from STM32WBAxx:
	Complete support (from IPxact)
	=======================================================
	STM32WBA55_v0r2:
	=======================================================
	Derived from STM32WBA52_v1r1
	Doc ID:  RM0493 Rev 3 - October 2023
	Adding support for COMP1/COMP2
	========================================================
	STM32WBA55_v0r3:
	=======================================================
	Doc ID:  RM0493 Rev 3 - October 2023
	Update in PWR/RCC registers
	Adding support for PTACONV
	
	
	
	=======================================================
	STM32WBA54_v0r1: initial release
	=======================================================
	Doc ID:  RM0493 Rev 3 - October 2023
	Renamed from STM32WBAxx:
	Complete support (from IPxact)
	=======================================================
	STM32WBA54_v0r2:
	=======================================================
	Derived from STM32WBA52_v1r1
	Doc ID:  RM0493 Rev 3 - October 2023
	Adding support for COMP1/COMP2
	========================================================
	STM32WBA54_v0r3:
	=======================================================
	Doc ID:  RM0493 Rev 3 - October 2023
	Update in PWR/RCC registers
	Adding support for PTACONV
	
	
	=======================================================
	STM32WBA52_v0r1: initial release
	=======================================================
	Doc ID:  RM0493 Rev 1 _ 5 January 2022 
	Renamed from STM32WBAxx_v0r3: 
	Complete support (from IPxact)
	=======================================================
	STM32WBA52_v1r0: official release
	=======================================================
	Doc ID:  RM0493 Rev 3 _ October 2023 
	=======================================================
	STM32WBA52_v1r1: 
	=======================================================
	Doc ID:  RM0493 Rev 3 _ October 2023 
	w/o support COMP1/COMP2/SAI1
	========================================================
	STM32WBA52_v1r2: 
	=======================================================
	Doc ID:  RM0493 Rev 3 - October 2023
	Update in PWR/RCC registers
		
		
	=======================================================
	STM32WBA50_v0r1: initial release
	=======================================================
	Doc ID:  RM0493 Rev 3 - October 2023
	Complete support (from IPxact)
	=======================================================
	STM32WBA50_v0r2: 
	=======================================================
	Derived from STM32WBA52_v1r1
	Doc ID:  RM0493 Rev 3 - October 2023
	Deleting support for secure access & Disable condition (Marketing decision)
	w/o SAES/COMP1/COMP2/GTZC/I2C1/LPTIM2/SPI1/TIM3/TIM17/USART2	
	========================================================
	STM32WBA50_v0r3: 
	=======================================================
	Doc ID:  RM0493 Rev 3 - October 2023
	Update in PWR/RCC registers
